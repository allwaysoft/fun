begin
for i in
(select 'MASTER' v, job_code, job_comp_code
from jcjob_table
-- where job_comp_code = '01'
and job_code not in
(select jsgp_job_code from da.jcjobsecgrpproj)
) loop
insert into da.jcjobsecgrpproj
(jsgp_group_code, jsgp_proj_code, jsgp_comp_code)
values
(i.v, i.job_code, i.job_comp_code)
;
end loop;
commit;
end;
/
