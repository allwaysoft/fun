PROMPT =======================================================
PROMPT Load objects for DC aplication
PROMPT =======================================================

start dcsys.sql

start dcidx.sql

start dcdb.sql

