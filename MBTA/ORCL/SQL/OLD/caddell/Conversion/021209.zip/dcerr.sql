select count(*)
, dcerr_err_type
, dcerr_column_name
, dcerr_description
from da.dc_error
where upper(dcerr_table_name) = 'DC_' || upper('&Table_Name')
group by dcerr_err_type, dcerr_column_name, dcerr_description
/
