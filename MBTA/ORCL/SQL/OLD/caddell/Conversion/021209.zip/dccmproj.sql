rem    syntax for running script: start dccmproj.sql
prompt SQL Script to link change orders to projects
prompt Run after importing all change orders and entering all projects.

update da.cmmast 
   set cmm_proj_oraseq = 
      (select pmp_proj_oraseq from da.pmproject_table
        where pmp_comp_code = cmm_comp_code 
          and pmp_job_code = cmm_job_code and rownum < 2)
 where cmm_proj_oraseq is null
   and (cmm_comp_code, cmm_job_code) in 
        (select pmp_comp_code, pmp_job_code 
           from da.pmproject_table);

commit;
