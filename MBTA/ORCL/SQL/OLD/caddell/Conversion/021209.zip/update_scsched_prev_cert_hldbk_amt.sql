update scsched
set scsch_prev_cert_amt =
(select sum(nvl(vou_inv_amt,0))
from voucher
where vou_ven_code = scsch_ven_code
and vou_cont_code = scsch_cont_code
and vou_rev_date is null
group by vou_ven_code, vou_cont_code)
where scsch_chg_code = '000'
and scsch_prev_cert_amt is null;

update scsched
set scsch_prev_hldbk_amt =
(select sum(nvl(vou_hldbk_amt,0))
from voucher
where vou_ven_code = scsch_ven_code
and vou_cont_code = scsch_cont_code
and vou_rev_date is null
group by vou_ven_code, vou_cont_code)
, scsch_prev_hldbk_rls_amt =
(select sum(nvl(vou_rls_amt,0))
from voucher
where vou_ven_code = scsch_ven_code
and vou_cont_code = scsch_cont_code
and vou_rev_date is null
group by vou_ven_code, vou_cont_code)
where scsch_chg_code = '000';

prompt Don't forget to Commit or Rollback


