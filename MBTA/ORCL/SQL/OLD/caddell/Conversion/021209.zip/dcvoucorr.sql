rem Script to update voucher outstanding and paid amounts based
rem on the cheques allocated to that voucher.
update da.voucher   a
   set (vou_inv_outstand_amt, vou_paid_amt) =
    (select  nvl(a.vou_inv_amt, 0) 
                 + nvl(a.vou_memo_amt, 0) 
                 - nvl(a.vou_hldbk_amt, 0)
                + decode(nvl(a.vou_tax1_direct_flag, 'N'), 'N', nvl(a.vou_tax_amt, 0), 0)
                + decode(nvl(a.vou_tax2_direct_flag, 'N'), 'N', nvl(a.vou_tax2_amt, 0), 0)
                + nvl(a.vou_frt_amt, 0)
                + nvl(a.vou_misc_amt, 0)
                - nvl(vou_disc_taken,0)
                - nvl(sum(nvl(v.vchq_pay_amt, 0)),0),
              nvl(sum(nvl(v.vchq_pay_amt, 0)),0)
       from da.cheque   c, da.vouchq    v
      where c.chq_seq_num = v.vchq_seq_num
        and c.chq_rev_date is null
        and c.chq_post_date is not null
        and v.vchq_vou_num = a.vou_num)
 where a.vou_post_date is not null
   and vou_rev_date is null
   and a.vou_num in 
(select b.vou_num
   from da.voucher b
  where (nvl(b.vou_inv_outstand_amt, 0),nvl(b.vou_paid_amt, 0)) not in ( select 
               nvl(b.vou_inv_amt, 0) 
                 + nvl(b.vou_memo_amt, 0) 
                 - nvl(b.vou_hldbk_amt, 0)
                + decode(nvl(b.vou_tax1_direct_flag, 'N'), 'N', nvl(b.vou_tax_amt, 0), 0)
                + decode(nvl(b.vou_tax2_direct_flag, 'N'), 'N', nvl(b.vou_tax2_amt, 0), 0)
                + nvl(b.vou_frt_amt, 0)
                + nvl(b.vou_misc_amt, 0)
                - nvl(b.vou_disc_taken,0)
                - nvl(sum(nvl(v1.vchq_pay_amt, 0)),0),
              nvl(sum(nvl(v1.vchq_pay_amt, 0)),0)
       from da.cheque   c1 , da.vouchq  v1
      where c1.chq_seq_num = v1.vchq_seq_num
        and c1.chq_rev_date is null
        and c1.chq_post_date is not null
        and v1.vchq_vou_num = b.vou_num)
    and b.vou_post_date is not null
    and b.vou_rev_date is null
)
/
