REM 06.78905 A. Stanciu - Procedure to create vourlsdet records based on voucher table
REm 07.88156 E.Gimelshtein  execute da.dbk_sys_context.set_sys_context('CMIC_JC',  'COMP_CODE_MASK'  , 'ZZ');
----this statment execute da.dbk_sys_context.set_sys_context('CMIC_JC',  'COMP_CODE_MASK'  , 'ZZ');
----has to be run evry time to set specific company code, otherwise it will update for the whole system
-- Therefore:
-- Step 1. execute da.dbk_sys_context.set_sys_context('CMIC_JC',  'COMP_CODE_MASK' , '01')
-- Step 2. start dbp_dc_vourlsdet
-- Step 3. execute dbp_dc_vourlsdet
 
create or replace procedure DBP_DC_VOURLSDET as
   cursor c_cur_vourel is select vou_comp_code, vou_job_code, vou_num, vou_ven_code, vou_cont_code, vou_chg_code,
                       vou_inv_code, (-1) * vou_hldbk_amt vou_hldbk_amt, vou_post_date, vou_bch_num
                       from da.voucher
                       where
                       vou_status_code not in ('V')
                       and vou_comp_Code = nvl(sys_context('CMIC_JC', 'COMP_CODE_MASK'), '%')
                       and vou_post_date   is not null
                       and vou_rev_date    is null
                       and nvl(vou_hldbk_amt,0) < 0
                       and vou_num not in (select vrd_vou_num from da.vourlsdet)
                        and     vou_num not in (select vrd_orig_vou_num from da.vourlsdet )
                       order by vou_post_date, vou_num;


    cursor vourlsdet_v_zero_lines_cur(p_comp_code varchar2,
 	                                p_job_code        varchar2,
	                                p_vou_num         number,
                                      p_ven_code        varchar2,
                                      p_cont_code       varchar2,
                                      p_chg_code        varchar2) is
              select vou_num,
                     vou_inv_code,
                     vou_post_date,
                     vou_hldbk_amt,
                     vou_rls_amt,
                     vou_job_code,
                     nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0) vou_ret_outstand_amt,
                     to_number(to_char(vou_post_date,'YYYYMMDD')) m_post_date,
                     vou_num m_vou_num
                from da.voucher
               where (  vou_job_code is null or vou_job_code = 'No Job')
	         and p_job_code is null  and vou_num != p_vou_num
	         and p_cont_code is null and (nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0)> 0)
               and vou_ven_code =p_ven_code
               and vou_comp_code = p_comp_code
               and vou_status_code not in ('V')
               and vou_post_date   is not null
               and vou_rev_date    is null
union all
              select vou_num,
                     vou_inv_code,
                     vou_post_date,
                     vou_hldbk_amt,
                     vou_rls_amt,
                     vou_job_code,
                     nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0) vou_ret_outstand_amt,
	               to_number(to_char(vou_post_date,'YYYYMMDD')) m_post_date,
		         vou_num m_vou_num
                from da.voucher
             where (vou_job_code = p_job_code
                     or vou_job_code in
                          (select job_code from da.jcjob_table
                            where job_comp_code = p_comp_code
                              and job_ctrl_code = p_job_code))
                 and vou_cont_code is null
                 and p_cont_code is null
                 and (nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0)> 0)
                 and vou_ven_code = p_ven_code
                 and vou_comp_code = p_comp_code
                 and vou_status_code not in ('V')
                 and vou_num != p_vou_num
                 and vou_post_date   is not null
                 and vou_rev_date    is null
union all
              select vou_num,
                     vou_inv_code,
                     vou_post_date,
                     vou_hldbk_amt,
                     vou_rls_amt,
                     vou_job_code,
                     nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0) vou_ret_outstand_amt,
	               to_number(to_char(vou_post_date,'YYYYMMDD')) m_post_date,
		         vou_num m_vou_num
                from da.voucher
             where ( vou_job_code = p_job_code
                     or vou_job_code in
                          (select job_code from da.jcjob_table
                            where job_comp_code = p_comp_code
                              and job_ctrl_code = p_job_code))
	         and  p_cont_code is not null
               and  vou_cont_code = p_cont_code
               and (nvl(vou_hldbk_amt,0) - nvl(vou_rls_amt,0)> 0)
               and vou_ven_code = p_ven_code
               and (vou_cont_code in (select scmst_cont_code
                                               from da.scmast
                                              where scmst_comp_code = vou_comp_Code
                                                and scmst_cont_Code = vou_cont_Code))
               and vou_comp_code = p_comp_code
               and vou_status_code not in ('V')
               and vou_num != p_vou_num
               and vou_post_date   is not null
               and vou_rev_date    is null
       order by 8,9;

t_rls_amt number:=0;
t_vou_rls_amt number:=0;

begin

-- select all the vouchers with negative release
for c_rec_vourel in c_cur_vourel loop

-- this is the initial release amount
t_rls_amt := c_rec_vourel.vou_hldbk_amt;

-- search for outstanding vouchers
for k in vourlsdet_v_zero_lines_cur(c_rec_vourel.vou_comp_code, c_rec_vourel.vou_job_code, c_rec_vourel.vou_num,
                                    c_rec_vourel.vou_ven_code, c_rec_vourel.vou_cont_code, c_rec_vourel.vou_chg_code) loop

t_vou_rls_amt := least(t_rls_amt, k.vou_ret_outstand_amt);

update da.voucher
set vou_rls_amt = nvl(vou_rls_amt,0) - NVL(t_vou_rls_amt,0)
where vou_num = c_rec_vourel.vou_num; -- this is the voucher which had negative retainage = release

update da.voucher
set vou_rls_amt = nvl(vou_rls_amt,0) + nvl(t_vou_rls_amt,0)
where vou_num = k.vou_num; -- this is the voucher with outstanding retainage  

if nvl(t_vou_rls_amt,0) <> 0 then
insert into da.vourlsdet
(vrd_comp_code 
,vrd_bch_num
,vrd_vou_num
,vrd_orig_vou_num 
,vrd_inv_code
,vrd_rls_amt
,vrd_rls_tax1_amt  --??
,vrd_rls_tax2_amt  -- ??
,vrd_post_date
,vrd_ven_code )
values
(c_rec_vourel.vou_comp_code
,c_rec_vourel.vou_bch_num
,c_rec_vourel.vou_num
,k.vou_num
,k.vou_inv_code
,nvl(t_vou_rls_amt,0)
,0
,0 
,c_rec_vourel.vou_post_date
,c_rec_vourel.vou_ven_code);
end if;

t_rls_amt := t_rls_amt - t_vou_rls_amt;
exit when vourlsdet_v_zero_lines_cur%notfound or t_rls_amt = 0;
end loop;

exit when c_cur_vourel%notfound;
end loop;
-----commit;
end;
/
show errors;
