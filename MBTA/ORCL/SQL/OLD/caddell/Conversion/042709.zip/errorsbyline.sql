SELECT DCERR_ROWNUM,
       DCERR_ERR_TYPE,
       DCERR_COLUMN_NAME,
       DCERR_DESCRIPTION
FROM DA.DC_ERROR
WHERE upper(DCERR_TABLE_NAME) = upper('DC_&table_name')
  AND DCERR_ROWNUM between &first_row and &last_row
ORDER BY DCERR_ROWNUM
/
