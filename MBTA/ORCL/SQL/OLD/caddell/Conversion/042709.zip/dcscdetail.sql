REM A. Stanciu - Procedure to create scdetail records based on SCMAST and SCCHED tables
REM L. Vanek   - Added 'distinct" keyword to prevent violation of unique key constraint
REM GG         - optimize ("GG1")
REM L. Vanek   - Split into to procedures by Jim Oriotis on March 18
REM            - Index hints added by L. Vanek on March 19
PROMPT ==============================================================================================
PROMPT DBP_DC_SCDETAIL
PROMPT ==============================================================================================

create or replace procedure DBP_DC_SCDETAIL as
begin
 for c_rec_scmst in (select scmst_comp_code, scmst_ven_code, scmst_cont_code, scmst_chg_code, scmst_job_code
                     from da.scmast
) loop
      delete /*+ index(a I_COMP_VEN_CONT_CHG_SCDETAIL) */
       from da.scdetail a
       where (a.scdet_comp_code, a.scdet_ven_code, a.scdet_cont_code,
              a.scdet_chg_code, a.scdet_sub_job_code, a.scdet_phs_code,
              a.scdet_cat_code) in 
       (select /*+ index(b I_COMP_VEN_CONT_CHG_SCDETAIL) */
               b.scdet_comp_code, b.scdet_ven_code, b.scdet_cont_code,
               b.scdet_chg_code, b.scdet_sub_job_code, b.scdet_phs_code,
               b.scdet_cat_code
          from da.scdetail  b
         where b.scdet_comp_Code = c_rec_scmst.scmst_comp_code 
           and b.scdet_ven_code = c_rec_scmst.scmst_ven_code
           and b.scdet_cont_code = c_rec_scmst.scmst_cont_Code
           and b.scdet_chg_code = c_rec_scmst.scmst_chg_code 
         minus
        select scsch_comp_code, scsch_ven_code, scsch_cont_code,
               scsch_chg_code, scsch_job_code, scsch_phs_code,
               scsch_cat_code
          from da.scsched
         where scsch_comp_code = c_rec_scmst.scmst_comp_code
           and scsch_ven_code = c_rec_scmst.scmst_ven_code
           and scsch_cont_code = c_rec_scmst.scmst_cont_Code
           and scsch_chg_code = c_rec_scmst.scmst_chg_code );
      ---------------------------------------------------------------------
      --- Add missing SCDETAIL rows
      insert into da.scdetail
        ( SCDET_COMP_CODE,
          SCDET_VEN_CODE,
          SCDET_CONT_CODE,
          SCDET_CHG_CODE,
          SCDET_JOB_CODE,
          SCDET_JOB_CTRL_CODE,
          SCDET_SUB_JOB_CODE,
          SCDET_PHS_CTRL_CODE,
          SCDET_PHS_CODE,
          SCDET_CAT_CTRL_CODE,
      	  SCDET_CAT_CODE,
          SCDET_SUBCONTR_CODE,
          SCDET_WM_CODE)   
        ( select distinct scsch_comp_code
                ,scsch_ven_code
                ,scsch_cont_code
                ,scsch_chg_code
                ,c_rec_scmst.scmst_job_code -- GG3
                ,jcat_job_ctrl_code
                ,scsch_job_code
                ,jcat_phs_ctrl_code
                ,scsch_phs_code
                ,jcat_ctrl_code
                ,scsch_cat_code
                ,scsch_subcontr_code
                ,jcat_wm_code
            from da.scsched  a
                -- GG3 ,da.scmast
                ,da.jcjobcat
           where (a.scsch_comp_code, a.scsch_ven_code, a.scsch_cont_code, a.scsch_chg_code,
                  a.scsch_job_code, a.scsch_phs_code, a.scsch_cat_code) in 
              (select b.scsch_comp_code, b.scsch_ven_code, b.scsch_cont_code, b.scsch_chg_code,
                      b.scsch_job_code, b.scsch_phs_code, b.scsch_cat_code 
                 from da.scsched  b
                where b.scsch_comp_code = c_rec_scmst.scmst_comp_code
                  and b.scsch_ven_code = c_rec_scmst.scmst_ven_code
                  and b.scsch_cont_code = c_rec_scmst.scmst_cont_Code
                  and b.scsch_chg_code = c_rec_scmst.scmst_chg_code
                group by b.scsch_comp_code, b.scsch_ven_code, b.scsch_cont_code, b.scsch_chg_code,
                      b.scsch_job_code, b.scsch_phs_code, b.scsch_cat_code
                minus
               select /*+ index(b I_COMP_VEN_CONT_CHG_SCDETAIL) */
                      b.scdet_comp_code, b.scdet_ven_code, b.scdet_cont_code,
                      b.scdet_chg_code, b.scdet_sub_job_code, b.scdet_phs_code,
                      b.scdet_cat_code
                 from da.scdetail  b
                where b.scdet_comp_Code = c_rec_scmst.scmst_comp_code 
                  and b.scdet_ven_code = c_rec_scmst.scmst_ven_code
                  and b.scdet_cont_code = c_rec_scmst.scmst_cont_Code
                  and b.scdet_chg_code = c_rec_scmst.scmst_chg_code)
/* GG3
             and scmst_comp_code = scsch_comp_code
             and scmst_ven_code = scsch_ven_code
             and scmst_cont_code = scsch_cont_code
             and scmst_chg_code = scsch_chg_code
GG3 */
             and jcat_comp_code = scsch_comp_code
             and jcat_job_code = scsch_job_code
             and jcat_phs_code = scsch_phs_code
             and jcat_code = scsch_cat_code);
      ---------------------------------------------------------------------
      --- Update SCDETAIL amounts and tax amounts
      update /*+ index(a I_COMP_VEN_CONT_CHG_SCDETAIL) */
         da.scdetail  a
         set (scdet_cont_amt, scdet_cont_unit, scdet_total_non_credit_tax_amt) 
               = (select sum(scsch_amt), sum(scsch_unit),
                  sum(nvl(scsch_amt, 0) * (decode(nvl(tax1.artax_ap_credit_flag, 'N'), 'N', nvl(tax1.artax_percent, 0),0)
                                         + decode(nvl(tax2.artax_ap_credit_flag, 'N'), 'N', nvl(tax2.artax_percent, 0),0) 
                                         + decode(nvl(tax3.artax_ap_credit_flag, 'N'), 'N', nvl(tax3.artax_percent, 0),0) 
                                         + decode(nvl(tax4.artax_ap_credit_flag, 'N'), 'N', nvl(tax4.artax_percent, 0),0) 
                                         + decode(nvl(tax5.artax_ap_credit_flag, 'N'), 'N', nvl(tax5.artax_percent, 0),0))
                                   /100) 
                                 from da.artax   tax1
                                     ,da.artax   tax2
                                     ,da.artax   tax3
                                     ,da.artax   tax4
                                     ,da.artax   tax5
                                     ,da.scsched
                                where scsch_comp_code = a.scdet_comp_code
                                  and scsch_ven_code = a.scdet_ven_code
                                  and scsch_cont_code = a.scdet_cont_code
                                  and scsch_chg_code = a.scdet_chg_code
                                  and a.scdet_sub_job_code = scsch_job_code
                                  and a.scdet_phs_code = scsch_phs_code
                                  and a.scdet_cat_code = scsch_cat_code
                                  and tax1.artax_comp_code (+) = scsch_comp_code
                                  and tax1.artax_code (+) = scsch_tax1_code
                                  and tax2.artax_comp_code (+) = scsch_comp_code
                                  and tax2.artax_code (+) = scsch_tax2_code
                                  and tax3.artax_comp_code (+) = scsch_comp_code
                                  and tax3.artax_code (+) = scsch_tax3_code
                                  and tax4.artax_comp_code (+) = scsch_comp_code
                                  and tax4.artax_code (+) = scsch_tax4_code
                                  and tax5.artax_comp_code (+) = scsch_comp_code
                                  and tax5.artax_code (+) = scsch_tax5_code
                                  )
       where (a.scdet_comp_code, a.scdet_ven_code, a.scdet_cont_code,
              a.scdet_chg_code, a.scdet_sub_job_code, a.scdet_phs_code,
              a.scdet_cat_code) in 
           (select b.scsch_comp_code, b.scsch_ven_code, b.scsch_cont_code,
                   b.scsch_chg_code, b.scsch_job_code, b.scsch_phs_code,
                   b.scsch_cat_code
              from da.scsched  b  
             where b.scsch_comp_code = c_rec_scmst.scmst_comp_code
               and b.scsch_ven_code = c_rec_scmst.scmst_ven_code
               and b.scsch_cont_code = c_rec_scmst.scmst_cont_Code
               and b.scsch_chg_code = c_rec_scmst.scmst_chg_code
         group by b.scsch_comp_code, b.scsch_ven_code, b.scsch_cont_code,
                  b.scsch_chg_code, b.scsch_job_code, b.scsch_phs_code,
                  b.scsch_cat_code);
      ---------------------------------------------------------------------
      --- Update out of sync SCDETAIL controlling codes
      update da.scdetail  a
         set (scdet_job_ctrl_code, scdet_phs_ctrl_code, scdet_cat_ctrl_code)
            = (select jcat_job_ctrl_code, jcat_phs_ctrl_code, jcat_ctrl_code
                 from da.jcjobcat
                where a.scdet_comp_code = jcat_comp_code
                  and a.scdet_sub_job_code = jcat_job_code
                  and a.scdet_phs_code = jcat_phs_code
                  and a.scdet_cat_code = jcat_code)
       where a.rowid in
         (select /*+ index(b I_COMP_VEN_CONT_CHG_SCDETAIL) */
            b.rowid
            from da.scdetail  b, da.jcjobcat  c
           where b.scdet_comp_code = c.jcat_comp_code
             and b.scdet_job_code = c.jcat_job_code
             and b.scdet_phs_code = c.jcat_phs_code
             and b.scdet_cat_code = c.jcat_code
             and (nvl(b.scdet_job_ctrl_code, 'x') != c.jcat_job_ctrl_code
                   or
                  nvl(b.scdet_phs_ctrl_code, 'x') != c.jcat_phs_ctrl_code
                   or
                  nvl(b.scdet_cat_ctrl_code, 'x') != c.jcat_ctrl_code)
             and b.scdet_comp_code = c_rec_scmst.scmst_comp_code
             and b.scdet_ven_code = c_rec_scmst.scmst_ven_code
             and b.scdet_cont_code = c_rec_scmst.scmst_cont_Code
             and b.scdet_chg_code = c_rec_scmst.scmst_chg_code);
      ---------------------------------------------------------------------
      ---------------------------------------------------------------------
      --- Update SCMAST amount
      update da.scmast  a
         set (scmst_cont_amt, scmst_gst_amt, scmst_non_credit_tax_amt)
                   = (select sum(scsch_amt), 
                             sum(nvl(scsch_amt, 0) * (decode(nvl(tax1.artax_ap_credit_flag, 'N'), 'Y', nvl(tax1.artax_percent, 0),0)
                                                    + decode(nvl(tax2.artax_ap_credit_flag, 'N'), 'Y', nvl(tax2.artax_percent, 0),0) 
                                                    + decode(nvl(tax3.artax_ap_credit_flag, 'N'), 'Y', nvl(tax3.artax_percent, 0),0) 
                                                    + decode(nvl(tax4.artax_ap_credit_flag, 'N'), 'Y', nvl(tax4.artax_percent, 0),0) 
                                                    + decode(nvl(tax5.artax_ap_credit_flag, 'N'), 'Y', nvl(tax5.artax_percent, 0),0))
                                                    /100),
                             sum(nvl(scsch_amt, 0) * (decode(nvl(tax1.artax_ap_credit_flag, 'N'), 'N', nvl(tax1.artax_percent, 0),0)
                                                    + decode(nvl(tax2.artax_ap_credit_flag, 'N'), 'N', nvl(tax2.artax_percent, 0),0) 
                                                    + decode(nvl(tax3.artax_ap_credit_flag, 'N'), 'N', nvl(tax3.artax_percent, 0),0) 
                                                    + decode(nvl(tax4.artax_ap_credit_flag, 'N'), 'N', nvl(tax4.artax_percent, 0),0) 
                                                    + decode(nvl(tax5.artax_ap_credit_flag, 'N'), 'N', nvl(tax5.artax_percent, 0),0))
                                                    /100) 
                                 from da.artax   tax1
                                     ,da.artax   tax2
                                     ,da.artax   tax3
                                     ,da.artax   tax4
                                     ,da.artax   tax5
                                     ,da.scsched
                                where scsch_comp_code = a.scmst_comp_code
                                  and scsch_ven_code  = a.scmst_ven_code
                                  and scsch_cont_code = a.scmst_cont_code
                                  and scsch_chg_code  = a.scmst_chg_code
                                  and tax1.artax_comp_code (+) = scsch_comp_code
                                  and tax1.artax_code (+) = scsch_tax1_code
                                  and tax2.artax_comp_code (+) = scsch_comp_code
                                  and tax2.artax_code (+) = scsch_tax2_code
                                  and tax3.artax_comp_code (+) = scsch_comp_code
                                  and tax3.artax_code (+) = scsch_tax3_code
                                  and tax4.artax_comp_code (+) = scsch_comp_code
                                  and tax4.artax_code (+) = scsch_tax4_code
                                  and tax5.artax_comp_code (+) = scsch_comp_code
                                  and tax5.artax_code (+) = scsch_tax5_code
                                  )
     where (a.scmst_comp_code, a.scmst_ven_code, a.scmst_cont_code,
              a.scmst_chg_code) in 
         (select b.scmst_comp_code, b.scmst_ven_code, b.scmst_cont_code,
                 b.scmst_chg_code
            from da.scmast  b, da.scsched
           where b.scmst_comp_code = scsch_comp_code
             and b.scmst_comp_code = c_rec_scmst.scmst_comp_code
             and b.scmst_ven_code = scsch_ven_code
             and b.scmst_ven_code = c_rec_scmst.scmst_ven_code
             and b.scmst_cont_code = scsch_cont_code
             and b.scmst_cont_code = c_rec_scmst.scmst_cont_code
             and b.scmst_chg_code = scsch_chg_code
             and b.scmst_chg_code = c_rec_scmst.scmst_chg_code
           group by b.scmst_comp_code, b.scmst_ven_code, b.scmst_cont_code,
            b.scmst_chg_code);

  commit;
 end loop;
end DBP_DC_SCDETAIL;
/

show errors;

PROMPT ==============================================================================================
PROMPT DBP_DC_SCDETAIL2
PROMPT ==============================================================================================
create or replace procedure DBP_DC_SCDETAIL2 as
begin
-- GG2
-- when VDIST_scsch_oraseq = scsch_oraseq one assumes the following
-- scsch_cont_code = VDIST_CONT_CODE = scdet_cont_code
-- scsch_ven_code  = da.voucher.ven_code = scdet_cont_code
-- scsch_comp_code = VDIST_COMP_CODE = scdet_comp_code
-- BUT, while scsch_chg_code must match scdet_chg_code, "VDIST_CHG_CODE" might actually be different! (which is why only the oraseq is used to join scsched to voudist)
-- (One notes that the previous version of this script did indeed join VDIST_CHG_CODE to scdet_chg_code, and VERA says that is wrong)
-- scdet_phs_code and scdet_cat code cannot be null (and if vdist_job_code is not null, then vdist_phs_code and vdist_cat_code are not null)
-- Aside from the primary key (an oraseq) there is no unique key in da.scsched
-- Unique key on da.scdetail is comp-ven-cont-chg-subjob-phs-cat (nulls not allowed, and note "subjob" instead of "job") and they must match the same columns in the da.scsched (one da.scdetail to many da.scsched)
Declare
cursor c1 is
select 
        -- the da.scdetail key is these 7 columns (except for scsch_chg_code, they are the same as the corresponding da.voudist columns)
        s.scsch_comp_code
       ,s.scsch_ven_code
       ,s.scsch_cont_code
       ,s.scsch_chg_code
       ,s.scsch_job_code
       ,s.scsch_phs_code
       ,s.scsch_cat_code
       ,d.vdist_wm_code
       ,sum(DECODE(d.VDIST_TYPE_CODE,'C',0,nvl(d.VDIST_AMT,0))) v_SCDET_BILL_AMT
       ,sum(DECODE(d.VDIST_TYPE_CODE,'C',0
            ,DECODE(NVL(v.VOU_INV_AMT,0)+NVL(v.VOU_TAX2_AMT,0)+NVL(v.VOU_FRT_AMT,0)+NVL(v.VOU_MISC_AMT,0),0,0
              ,nvl(d.VDIST_AMT,0) *(nvl(v.VOU_HLDBK_AMT,0)
                                   +nvl(v.VOU_TAX_HLDBK_AMT,0)
                                   +nvl(v.VOU_TAX2_HLDBK_AMT,0)
                                   )/(NVL(v.VOU_INV_AMT,0)
                                     +NVL(v.VOU_TAX2_AMT,0)
                                     +NVL(v.VOU_FRT_AMT,0)
                                     +NVL(v.VOU_MISC_AMT,0)
                                     )
                   )
                  )
           )                                                     v_SCDET_HLDBK_AMT
       ,sum(DECODE(d.VDIST_TYPE_CODE,'C',-nvl(d.VDIST_AMT,0),0)) v_SCDET_CHGBCK_AMT
       ,sum(nvl(d.VDIST_QTY,0))                                  v_vdist_qty
       ,sum(DECODE(NVL(v.VOU_INV_AMT,0)+NVL(v.VOU_TAX2_AMT,0)+NVL(v.VOU_FRT_AMT,0)+NVL(v.VOU_MISC_AMT,0),0,0
             ,nvl(d.VDIST_AMT,0) * (nvl(v.VOU_TAX_AMT,0)
                                   +nvl(v.VOU_TAX_HLDBK_AMT,0)
                                   +nvl(v.VOU_TAX2_HLDBK_AMT,0)
                                   )/(NVL(v.VOU_INV_AMT,0)
                                     +NVL(v.VOU_TAX2_AMT,0)
                                     +NVL(v.VOU_FRT_AMT,0)
                                     +NVL(v.VOU_MISC_AMT,0)
                                     )
                  )
           )                                                     v_SCDET_GST_AMT
from  da.voudist d
     ,da.voucher v
     ,da.scsched s
where d.vdist_scsch_oraseq is NOT null
  AND d.vdist_source_code  IS     null
  AND d.vdist_type_code    IN ('J','C')
  -- amount data (for holdback) is only from da.voucher
  AND v.vou_num      = d.vdist_vou_num
  and v.vou_post_date is NOT null
  and v.vou_rev_date  IS     null
  -- the join is ONLY for the purpose of reading the correct scsch_chg_code
  AND s.scsch_oraseq = d.VDIST_scsch_oraseq
group by 
        s.scsch_comp_code
       ,s.scsch_ven_code
       ,s.scsch_cont_code
       ,s.scsch_chg_code
       ,s.scsch_job_code
       ,s.scsch_phs_code
       ,s.scsch_cat_code
       ,d.vdist_wm_code
order by 
        s.scsch_comp_code
       ,s.scsch_ven_code
       ,s.scsch_cont_code
       ,s.scsch_chg_code
       ,s.scsch_job_code
       ,s.scsch_phs_code
       ,s.scsch_cat_code
       ,d.vdist_wm_code
;
c1_rec             c1%rowtype;
c1_prev_rec        c1%rowtype;
t_SCDET_BILL_AMT   number;
t_SCDET_HLDBK_AMT  number;
t_SCDET_CHGBCK_AMT number;
t_vdist_qty        number;
t_SCDET_GST_AMT    number;
t                  pls_integer:=0;
Begin
open  c1;
fetch c1 into c1_rec;
while (c1%found) loop
   c1_prev_rec        :=c1_rec;
   t_SCDET_BILL_AMT   :=0;
   t_SCDET_HLDBK_AMT  :=0;
   t_SCDET_CHGBCK_AMT :=0;
   t_vdist_qty        :=0;
   t_SCDET_GST_AMT    :=0;
   -- because of the WM conversion, it is necessary to do a procedural loop to sum, what may be, multiple different WM in da.voudist into the WM of da.scdetail
   -- this "for" loop returns only one row (followed by a "while" loop which may return multiple rows)
   for i in (select  o.rowid         v_rowid
                    ,o.scdet_wm_code
               from  da.scdetail   o
              WHERE   o.SCDET_COMP_CODE    = c1_rec.scsch_comp_code
                and   o.SCDET_VEN_CODE     = c1_rec.scsch_ven_code
                and   o.SCDET_CONT_CODE    = c1_rec.scsch_cont_code
                and   o.SCDET_CHG_CODE     = c1_rec.scsch_chg_code
                and   o.SCDET_SUB_JOB_CODE = c1_rec.scsch_job_code
                and   o.SCDET_PHS_CODE     = c1_rec.scsch_phs_code
                and   o.SCDET_CAT_CODE     = c1_rec.scsch_cat_code
            ) loop
      while(
                c1_rec.scsch_cat_code =c1_prev_rec.scsch_cat_code
            and c1_rec.scsch_phs_code =c1_prev_rec.scsch_phs_code
            and c1_rec.scsch_job_code =c1_prev_rec.scsch_job_code
            and c1_rec.scsch_chg_code =c1_prev_rec.scsch_chg_code
            and c1_rec.scsch_cont_code=c1_prev_rec.scsch_cont_code
            and c1_rec.scsch_ven_code =c1_prev_rec.scsch_ven_code
            and c1_rec.scsch_comp_code=c1_prev_rec.scsch_comp_code
            and c1%found 
          ) loop
            t_SCDET_BILL_AMT   :=t_SCDET_BILL_AMT  +c1_rec.v_SCDET_BILL_AMT;
            t_SCDET_HLDBK_AMT  :=t_SCDET_HLDBK_AMT +c1_rec.v_SCDET_HLDBK_AMT;
            t_SCDET_CHGBCK_AMT :=t_SCDET_CHGBCK_AMT+c1_rec.v_SCDET_CHGBCK_AMT;
            t_SCDET_GST_AMT    :=t_SCDET_GST_AMT   +c1_rec.v_SCDET_GST_AMT;
            -- if WM is the same, no conversion
            if   c1_rec.vdist_wm_code=i.scdet_wm_code
            then t_vdist_qty   :=t_vdist_qty+c1_rec.v_vdist_qty;
            else 
                    -- if WM is different, convert
                    declare
                         tt   number:=0;
                         cursor c2 is 
                         select  c1_rec.v_VDIST_QTY * nvl(w.WC_CONV_NUM,1) 
                           FROM  DA.WGTCONV  w
                          WHERE  w.WC_COMP_CODE    = c1_rec.scsch_comp_code
                            AND  w.WC_DEPT_CODE    = '00'
                            AND  w.WC_WM_FROM_CODE = c1_rec.vdist_wm_code
                            AND  w.WC_WM_TO_CODE   = i.scdet_wm_code;
                    Begin
                     open  c2;
                     fetch c2 into tt;
                     close c2; 
                     t_vdist_qty:=t_vdist_qty+nvl(tt,0);
                   End;
            end if;
      fetch c1 into c1_rec;
      end loop;
      -- all WM for the given key have now been converted
      update da.scdetail u
             set u.SCDET_BILL_AMT  =t_SCDET_BILL_AMT
                ,u.SCDET_HLDBK_AMT =t_SCDET_HLDBK_AMT
                ,u.SCDET_CHGBCK_AMT=t_SCDET_CHGBCK_AMT
                ,u.SCDET_GST_AMT   =t_SCDET_GST_AMT
                ,u.SCDET_INV_UNIT  =t_vdist_qty
                ,u.scdet_hldbk_rls_amt=0
      where u.rowid=i.v_rowid;
      t:=t+1;
      if t>100 then commit; t:=0; end if;
      exit; -- exit the "for" loop which is only one da.scdetail row
   end loop;
end loop;
commit;
end;
end DBP_DC_SCDETAIL2;
/

show errors;


