#06.79163 A. Stanciu - created the conversion script
 
set serveroutput on
set verify off
PROMPT Please enter valid company code (vcomp_code): 
accept vcomp_code char prompt 'Company Code: '

declare
cursor c_vdist(p_comp_code in varchar2, p_ven_code in varchar2, p_cont_code in varchar2, p_job_code in varchar2, p_phs_code in varchar2, p_cat_code in varchar2) is 
select   count(*), sum(nvl(vdist_amt,0)),
          sum(nvl(vdist_amt,0)),
            sum(nvl(vdist_qty,0)),
            sum(nvl(vdist_qty,0)) 
       from da.voudist vdist
           ,voucher    vou
       where vdist_source_code is null
       and   vdist_post_date is not null
       and   vdist_vou_num = vou_num
       and   vou_rev_date is null 
       and   vou_ven_code = p_ven_code
       and   vdist_comp_code = '&vcomp_code'
       and   vdist_cont_code = p_cont_code
       and   vdist_job_code = p_job_code
       and   vdist_phs_code = p_phs_code
       and   vdist_cat_code = p_cat_code
       and   vdist_vou_num < 0
       ;

cursor c_sched_det (p_comp_code varchar2,
p_ven_code varchar2,
p_cont_code in varchar2, p_job_code in varchar2, p_phs_code in varchar2, p_cat_code in varchar2) is
select negative_rec.scsch_chg_code scsch_chg_code, negative_rec.scsch_remaining_amt scsch_remaining_amt from 
(select scsch_chg_code, nvl(scsch_amt, 0) - nvl(scsch_compl_amt,0) scsch_remaining_amt
from da.scsched
where scsch_comp_Code = p_comp_code
and scsch_cont_code = p_cont_code
and scsch_ven_code = p_ven_code
and scsch_job_code = p_job_code
and scsch_phs_code = p_phs_code
and scsch_cat_code = p_cat_code
and nvl(scsch_amt, 0) - nvl(scsch_compl_amt,0) < 0
order by nvl(scsch_amt, 0) - nvl(scsch_compl_amt,0)) negative_rec
union all
select positive_rec.scsch_chg_code, positive_rec.scsch_remaining_amt from 
(select scsch_chg_code, nvl(scsch_amt, 0) - nvl(scsch_compl_amt,0) scsch_remaining_amt
from da.scsched
where scsch_comp_Code = p_comp_code
and scsch_cont_code = p_cont_code
and scsch_ven_code = p_ven_code
and scsch_job_code = p_job_code
and scsch_phs_code = p_phs_code
and scsch_cat_code = p_cat_code
and nvl(scsch_amt, 0) - nvl(scsch_compl_amt,0) > 0
order by scsch_chg_code) positive_rec;

vvdist_sum number;
vvdist_count number;
vvdist_qty number;
t_compl_amt number;


begin
-- total budget for a contract for a specific job, phs, cat
for c_scsched_total in (
select scsch_comp_code, scsch_ven_code, scsch_cont_code, scsch_job_code, scsch_phs_code, scsch_cat_code, sum(scsch_amt) sum_scsch_amt
from da.scsched where scsch_comp_code ='&vcomp_code' 
-- and scsch_cont_code = '&vcont_code'
group by scsch_comp_code, scsch_ven_code, scsch_cont_code, scsch_job_code, scsch_phs_code, scsch_cat_code
) loop
       t_compl_amt:=0; 
--       dbms_output.put_line('P-1 '||c_scsched_total.scsch_job_code||';'||c_scsched_total.scsch_phs_code||';'||c_scsched_total.scsch_cat_code||';'||c_scsched_total.sum_scsch_amt);
open c_vdist ('&vcomp_code', c_scsched_total.scsch_ven_code, c_scsched_total.scsch_cont_code, c_scsched_total.scsch_job_code, c_scsched_total.scsch_phs_code, c_scsched_total.scsch_cat_code);
fetch c_vdist into vvdist_count, vvdist_sum, vvdist_sum, vvdist_qty, vvdist_qty;
--       dbms_output.put_line('P0 '||vvdist_count||';'||vvdist_sum);
if vvdist_count <> 0 then
  -- dbms_output.put_line('Proceed ...Contract '||c_scsched_total.scsch_cont_code||';'||c_scsched_total.sum_scsch_amt);
   for c_sched_rec in c_sched_det('&vcomp_code', c_scsched_total.scsch_ven_code, c_scsched_total.scsch_cont_code, c_scsched_total.scsch_job_code, c_scsched_total.scsch_phs_code, c_scsched_total.scsch_cat_code) loop
--       dbms_output.put_line('Pscsched_rec '||c_sched_rec.scsch_remaining_amt);
    if c_sched_rec.scsch_remaining_amt < 0 then
       vvdist_sum := vvdist_sum - c_sched_rec.scsch_remaining_amt;
--       dbms_output.put_line('P1 '||t_compl_amt);

     update da.scsched 
     Set scsch_compl_amt = scsch_amt,
         Scsch_prev_cert_amt = scsch_amt,
         Scsch_compl_pct = 100
     where scsch_comp_code = '&vcomp_code'
     and scsch_ven_code = c_scsched_total.scsch_ven_code
     and scsch_cont_code = c_scsched_total.scsch_cont_code
     and scsch_chg_code = c_sched_rec.scsch_chg_code
     and scsch_job_code = c_scsched_total.scsch_job_code
     and scsch_phs_code = c_scsched_total.scsch_phs_code
     and scsch_cat_code = c_scsched_total.scsch_cat_code;

    else
       t_compl_amt := least(vvdist_sum, c_sched_rec.scsch_remaining_amt);
--       dbms_output.put_line('P2 '||t_compl_amt);

     update da.scsched 
     Set scsch_compl_amt = t_compl_amt,
         Scsch_prev_cert_amt = t_compl_amt,
         Scsch_compl_pct = decode(nvl(scsch_amt, 0), 0 , 100, 
              sign(round(nvl(t_compl_amt,0)/scsch_amt*100,3)) *
                    least(abs(round(nvl(t_compl_amt,0)/scsch_amt*100,3)),999.999))
     where scsch_comp_code = '&vcomp_code'
     and scsch_ven_code = c_scsched_total.scsch_ven_code
     and scsch_cont_code = c_scsched_total.scsch_cont_code
     and scsch_chg_code = c_sched_rec.scsch_chg_code
     and scsch_job_code = c_scsched_total.scsch_job_code
     and scsch_phs_code = c_scsched_total.scsch_phs_code
     and scsch_cat_code = c_scsched_total.scsch_cat_code;

     vvdist_sum := vvdist_sum - t_compl_amt;
    end if;

--      dbms_output.put_line('Updated '||sql%rowcount);
     exit when c_sched_det%notfound or  vvdist_sum = 0;

   end loop;
end if;
close c_vdist;
end loop;
end ;
/