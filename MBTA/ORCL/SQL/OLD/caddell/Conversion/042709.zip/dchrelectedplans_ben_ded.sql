-- This script will populated PYEMPBEN and PYEMPDED with records from the HREMELECTEDPLANS_EM table.


Begin
For eld in (select eld_bd_oraseq, eld_emp_no, eld_comp_code, eld_prn_code, eld_effective_date
              from da.HRELECTEDPLANS_EM
           )
Loop
   DA.DBK_HR_INSERT.P_EmployeeLevel_Data (eld.eld_bd_oraseq,
                                                                       eld.eld_emp_no,
                                                                       eld.eld_comp_code,
                                                                       eld.eld_prn_code,
                                                                       eld.eld_effective_date);
End loop;
End;
/
