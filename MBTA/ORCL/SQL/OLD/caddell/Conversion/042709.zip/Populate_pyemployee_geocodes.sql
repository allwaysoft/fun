Spool EmpList.txt
Prompt ======================================================
Prompt		Creating Temporary Table
Prompt ======================================================
Drop Table da.PYMultiGeoEmpListing;
---
Create Table da.PYMultiGeoEmpListing
(geo_emp_no		Varchar2(16)
,geo_state_code		Varchar2(10)
,geo_profile_geocode	Varchar2(9)
);
--
Prompt non-alpha-numeric characters
set feedback 1
select
 count(0)
,translate(upper(EMP_ADDRESS3),'. 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ','.')
from da.pyemployee_table
group by translate(upper(EMP_ADDRESS3),'. 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ','.')
/

--
set serveroutput on size 1000000
--
Prompt =======================================================================
Prompt		Running Script to Update GEOCODE Please wait .......
Prompt =======================================================================
Declare
        TYPE ra_char_int_type  is table of varchar2(250) index by pls_integer;
        TYPE ra_char_char_type is table of varchar2(250) index by varchar2(2);
        ra_state  ra_char_int_type;
        ra_statec ra_char_char_type;
        -- replace non-character data
        t_string varchar2(9):='A #''-./,'||chr(38);
--
	c_empstate	Varchar2(10);
	c_empgeostate	pls_integer;
--
	      Cursor c_EmpAddress Is
	      Select  rowid empTable_Rowid
	  	     ,emp_zip_code
	    	     ,emp_state_code
	    	     ,emp_no
                      -- convert city to upper case and remove some non-alphanumeric characters
	    	     ,translate(upper(EMP_ADDRESS3),t_string,'A')
                      v_city
	    	     ,emp_county_code
   	       from da.pyemployee_table
	       Where emp_zip_code is not null
		 and emp_vertex_geocode = 'NA'
	         and emp_country_code   = 'US';
		--
		-- zip code only
	       cursor c_geocode_zip(p_empZip_code in Varchar2) is
	       select vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity
	             ,  lpad(to_char(vcity.locgeostate) , 2, '0')
	              ||lpad(to_char(vcity.locgeocounty), 3, '0')
	              ||lpad(to_char(vcity.locgeocity)  , 4, '0') vert_code
	         from da.vertex_loccity vcity
	         where rpad(p_empzip_code,6,' ') between loczipcodestart and loczipcodeend
                   -- if there is a state on employee, match the state code
                   and decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcity.locgeostate)
	        Group by vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity;
                --
	        ziprec			c_geocode_zip%RowType;
	        ziprec2			c_geocode_zip%RowType;
	        ziprec3			c_geocode_zip%RowType;
	        TotalZipRows		pls_integer;
                --
		-- zip code and city name
	       cursor c_geocode_zip_city(p_empZip_code in Varchar2, p_CityName in varchar2) is
	       select vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity
	             ,  lpad(to_char(vcity.locgeostate) , 2, '0')
	              ||lpad(to_char(vcity.locgeocounty), 3, '0')
	              ||lpad(to_char(vcity.locgeocity)  , 4, '0') vert_code
	         from da.vertex_loccity vcity
	         where rpad(p_empzip_code,6,' ') between loczipcodestart and loczipcodeend
                   and p_CityName in
                       ( translate(upper(vcity.LOCCOMPRESSEDCITY),t_string,'A')
                        ,translate(upper(vcity.LOCABBREVCITY    ),t_string,'A')
                        ,translate(upper(vcity.LOCNAMECITY      ),t_string,'A') 
                       )
                   -- if there is a state on employee, match the state code
                   and decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcity.locgeostate)
	        Group by vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity;
                --
		-- zip code and city name and county
	       cursor c_geocode_zip_city_county(p_empZip_code in Varchar2, p_CityName in varchar2, p_geostate in pls_integer, p_geocounty in pls_integer) is
	       select vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity
	             ,  lpad(to_char(vcity.locgeostate) , 2, '0')
	              ||lpad(to_char(vcity.locgeocounty), 3, '0')
	              ||lpad(to_char(vcity.locgeocity)  , 4, '0') vert_code
	         from da.vertex_loccity vcity
	         where rpad(p_empzip_code,6,' ') between loczipcodestart and loczipcodeend
                   and p_CityName in
                       ( translate(upper(vcity.LOCCOMPRESSEDCITY),t_string,'A')
                        ,translate(upper(vcity.LOCABBREVCITY    ),t_string,'A')
                        ,translate(upper(vcity.LOCNAMECITY      ),t_string,'A') 
                       )
		   and vcity.locgeostate = p_geostate
                   and vcity.locgeocounty= p_geocounty
                   -- if there is a state on employee, match the state code
                   and decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcity.locgeostate)
	        Group by vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity;
                --
		-- zip code and county (without city name)
	       cursor c_geocode_zip_county(p_empZip_code in Varchar2, p_geostate in number, p_geocounty in number) is
	       select vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity
	             ,  lpad(to_char(vcity.locgeostate) , 2, '0')
	              ||lpad(to_char(vcity.locgeocounty), 3, '0')
	              ||lpad(to_char(vcity.locgeocity)  , 4, '0') vert_code
	         from da.vertex_loccity vcity
	         where rpad(p_empzip_code,6,' ') between loczipcodestart and loczipcodeend
		   and vcity.locgeostate = p_geostate
                   and vcity.locgeocounty= p_geocounty
                   -- if there is a state on employee, match the state code
                   and decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcity.locgeostate)
	        Group by vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity;
                --
		-- county (without city name and without zip)
	       cursor c_geocode_county(p_geostate in number, p_geocounty in number) is
	       select vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity
	             ,  lpad(to_char(vcity.locgeostate) , 2, '0')
	              ||lpad(to_char(vcity.locgeocounty), 3, '0')
	              ||lpad(to_char(vcity.locgeocity)  , 4, '0') vert_code
	         from da.vertex_loccity vcity
	         where vcity.locgeostate = p_geostate
                   and vcity.locgeocounty= p_geocounty
                   -- if there is a state on employee, match the state code
                   and decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcity.locgeostate)
	        Group by vcity.locgeostate, vcity.locgeocounty, vcity.locgeocity;
               --
               --
	       cursor c_county(p_geostate in number, p_CountyName in varchar2, p_County_shortName in varchar2) is
	       select vcounty.locgeostate, vcounty.locgeocounty
	         from da.vertex_loccounty vcounty
	         where decode(c_empgeostate,null,' ',c_empgeostate) = decode(c_empgeostate,null,' ',vcounty.locgeostate)
                   and (
                       p_CountyName 
                       in
                       (translate(upper(LOCNAMECOUNTY)  ,t_string,'A')
                       ,translate(upper(LOCABBREVCOUNTY),t_string,'A')
                       )
                       or
                       p_County_shortName 
                       in
                       (translate(upper(LOCNAMECOUNTY)  ,t_string,'A')
                       ,translate(upper(LOCABBREVCOUNTY),t_string,'A')
                       )
                       )
	        Group by vcounty.locgeostate, vcounty.locgeocounty;
                countyrec               c_county%rowtype;
                countyrec2              c_county%rowtype;
		---	
	Cursor c_county_info(p_state in Varchar2, p_county in varchar2) Is
	Select  translate(upper(CNT_COUNTY_NAME),t_string,'A')
                CNT_COUNTY_NAME
               ,translate(upper(CNT_SHORT_NAME),t_string,'A')
                CNT_SHORT_NAME
          from da.pycounty
         where CNT_COUNTRY_CODE = 'US'
           and CNT_STATE_CODE   = p_state      
           and CNT_COUNTY_CODE  = p_county;
        c_countyrec     c_county_info%ROWTYPE;
        c_countyrec2    c_county_info%ROWTYPE;
Begin
-- state code
for i in (select locgeostate, locabbrevstate from da.vertex_locstate order by 1) loop
  ra_state (i.locgeostate)   :=i.locabbrevstate;
  ra_statec(i.locabbrevstate):=i.locabbrevstate;
end loop;
-- main loop
For EmpRec in c_EmpAddress
Loop

   c_empstate   :=null;
   c_empgeostate:=null;
   ziprec       :=ziprec3;
   ziprec2      :=ziprec3;
   countyrec.locgeostate :=null;
   countyrec.locgeocounty:=null;

   if EmpRec.emp_state_code is null
      then dbms_output.put_line('Emp='||EmpRec.emp_no||' missing state code.');
           goto L_endloop;
      else if ra_statec.exists(EmpRec.emp_state_code)
              then c_empgeostate:=ra_statec(EmpRec.emp_state_code);
              else dbms_output.put_line('Emp='||EmpRec.emp_no||' Unknown state code:'||EmpRec.emp_state_code);
                   goto L_endloop;
           end if;
   end if;

   -- county information
   If  EmpRec.emp_state_code  is not null
   and EmpRec.emp_county_code is not null
   and c_empgeostate          is not null
   then
     Open  c_county_info(EmpRec.emp_state_code, EmpRec.emp_county_code);
     Fetch c_county_info into c_countyrec;
     if    c_county_info%found 
     then Fetch c_county_info into c_countyrec2;
          if c_county_info%found
             then dbms_output.put_line('Emp='||EmpRec.emp_no||' Same county code more than once in da.pycounty:'||EmpRec.emp_state_code||'-'||EmpRec.emp_county_code);
             else open  c_county (c_empgeostate, c_countyrec2.CNT_COUNTY_NAME, c_countyrec2.CNT_SHORT_NAME);
                  fetch c_county into countyrec;
                  if c_county%found
                     then fetch c_county into countyrec2;
                          if  c_county%found
                              then dbms_output.put_line('Emp='||EmpRec.emp_no||' County name found more than once in veretx_loccounty:'||to_char(c_empgeostate)||' '||c_countyrec2.CNT_COUNTY_NAME||' '||c_countyrec2.CNT_SHORT_NAME);
                                   countyrec.locgeostate :=null;
                                   countyrec.locgeocounty:=null;
                           end if;        
                     else dbms_output.put_line('Emp='||EmpRec.emp_no||' County name not found in veretx_loccounty:'||to_char(c_empgeostate)||' '||c_countyrec2.CNT_COUNTY_NAME||' '||c_countyrec2.CNT_SHORT_NAME);
                  end if;
                  close c_county;
          end if;
     else dbms_output.put_line('Emp='||EmpRec.emp_no||' County code not found in da.pycounty:'||EmpRec.emp_state_code||'-'||EmpRec.emp_county_code);
     end if;
     Close c_county_info;
   End if;

   -- find how many geocode-rows match the employee zip-code
   Open  c_geocode_zip(EmpRec.emp_zip_code);
   Fetch c_geocode_zip into ziprec;
   if c_geocode_zip%found
   then 
        Fetch c_geocode_zip into ziprec2;
        if   c_geocode_zip%found
        then -- more than one row matches the zip code
             TotalZipRows:=2;
        else -- only one row with the given zip code
             TotalZipRows:=1;
        end if;
   else -- no zip code match at all
        TotalZipRows:=0; 
   end if;
   close c_geocode_zip;

   -- more than one geocode-row matches the employee zip-code when matching by zip-code only
   -- try again by limiting the search to the employee-city within the employee zip-code
   if 2 = TotalZipRows then
     Open  c_geocode_zip_city(EmpRec.emp_zip_code, EmpRec.v_city);
     Fetch c_geocode_zip_city into ziprec;
     if c_geocode_zip_city%found
     then 
        Fetch c_geocode_zip_city into ziprec2;
        if c_geocode_zip_city%found
        then -- multiple rows with the given zip code
             TotalZipRows:=2;
        else -- only one row with the given zip code
             TotalZipRows:=1;
        end if;
     else -- no zip code match at all
          TotalZipRows:=0; 
     end if;
     close c_geocode_zip_city;
   end if;

   -- more than one geocode-row matches the employee zip-code when matching by both zip-code and city-name
   -- try again by limiting the search to the employee-county within the employee zip-code-city-name
   if 2 = TotalZipRows then
     Open  c_geocode_zip_city_county(EmpRec.emp_zip_code, EmpRec.v_city, countyrec.locgeostate, countyrec.locgeocounty);
     Fetch c_geocode_zip_city_county into ziprec;
     if c_geocode_zip_city_county%found
     then 
        Fetch c_geocode_zip_city_county into ziprec2;
        if c_geocode_zip_city_county%found
        then -- multiple rows with the given zip code
             TotalZipRows:=2;
        else -- only one row with the given zip code
             TotalZipRows:=1;
        end if;
     else -- no zip code match at all
          TotalZipRows:=0; 
     end if;
     close c_geocode_zip_city_county;
   end if;

   -- if there is no match at this point, then try employee-zipcode-county without city
   if 0 = TotalZipRows then
     Open  c_geocode_zip_county(EmpRec.emp_zip_code, countyrec.locgeostate, countyrec.locgeocounty);
     Fetch c_geocode_zip_county into ziprec;
     if c_geocode_zip_county%found
     then 
        Fetch c_geocode_zip_county into ziprec2;
        if c_geocode_zip_county%found
        then -- multiple rows with the given zip code
             TotalZipRows:=2;
        else -- only one row with the given zip code
             TotalZipRows:=1;
        end if;
     else -- no zip code match at all
          TotalZipRows:=0; 
     end if;
     close c_geocode_zip_county;
   end if;

   -- if there is no match at this point, then try employee-county without city and without zip code
   if 0 = TotalZipRows then
     Open  c_geocode_county(countyrec.locgeostate, countyrec.locgeocounty);
     Fetch c_geocode_county into ziprec;
     if c_geocode_county%found
     then 
        Fetch c_geocode_county into ziprec2;
        if c_geocode_county%found
        then -- multiple rows with the given zip code
             TotalZipRows:=2;
        else -- only one row with the given zip code
             TotalZipRows:=1;
        end if;
     else -- no zip code match at all
          TotalZipRows:=0; 
     end if;
     close c_geocode_county;
   end if;

   -- final test - if there is only one match, then update; otherwise (either more than one match or no match at all) then record as error
   -- in any case there is no real need to record the error, because the master table is not updated and the master table may be listed for rows that have no geocode
   if 1 = TotalZipRows then
         -- only one geocode-row matches the employee zip-code
         c_empstate:=ra_state(ziprec.locgeostate);

         If c_empstate=EmpRec.emp_state_code
            then 
               Begin       
                Update da.pyemployee_table
            	     set emp_vertex_geocode = ziprec.vert_code
         	        ,emp_state_code     = c_empstate
         	   where rowid = empRec.empTable_Rowid;
         
                 Update da.pyemphist
         	      set emh_vertex_geocode   = ziprec.vert_code
         	         ,emh_emp_state_code   = c_empstate
         	    where emh_emp_no = empRec.emp_no;      
         	 Exception
         	   When Others then dbms_output.put_line('Emp='||EmpRec.emp_no||' update error '||sqlerrm);
                 End;
            else dbms_output.put_line('Emp='||EmpRec.emp_no||' State code error.');
         End If;
   -- 
   else
   --
	Insert into da.PYMultiGeoEmpListing
	(geo_emp_no
	,geo_state_code
	,geo_profile_geocode
	)
	values
	(EmpRec.emp_no
	,Substr(c_empstate||'-'||EmpRec.emp_state_code,1,10)
	,Substr('ER:'||EmpRec.emp_zip_code,1,9)
	);
   end if;
   commit;
   << L_endloop >>
      null;
End loop;   
End;
/


prompt ==================================================
prompt	  Employee number with Multiple GeoCodes
prompt ==================================================
Select distinct geo_emp_no EmpNo, geo_state_code StateCode,  geo_profile_geocode ProfileGeo from da.PYMultiGeoEmpListing order by 1;
Spool off
Prompt Spool file created EmpList.txt
