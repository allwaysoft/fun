update pyemppayhist
set phy_pay_date =
(select PPR_PAY_DATE
from pycompayprd
where PPR_COMP_CODE = phy_comp_code
and PPR_PRN_CODE = phy_prn_code
and PPR_YEAR = phy_ppr_year
and PPR_PERIOD = phy_ppr_period)
where phy_pay_date is null
and phy_emp_no in
(select distinct phy_emp_no
from pyemppayhist
where phy_pay_date is null);

update pyemppayhist
set phy_expected_post_date =
(select ppr_posting_date
from pycompayprd
where PPR_COMP_CODE = phy_comp_code
and PPR_PRN_CODE = phy_prn_code
and PPR_YEAR = phy_ppr_year
and PPR_PERIOD = phy_ppr_period)
where phy_expected_post_date is null
and phy_emp_no in
(select distinct phy_emp_no
from pyemppayhist
where phy_expected_post_date is null);

update pyemppayhist
set phy_month_number =
(select ppr_month
from pycompayprd
where PPR_COMP_CODE = phy_comp_code
and PPR_PRN_CODE = phy_prn_code
and PPR_YEAR = phy_ppr_year
and PPR_PERIOD = phy_ppr_period)
where phy_month_number is null
and phy_emp_no in
(select distinct phy_emp_no
from pyemppayhist
where phy_month_number is null);