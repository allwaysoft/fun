REM 06.78905 A. Stanciu - Procedure to create invrlsdet records based on invoice table
create or replace procedure DBP_DC_INVRLSDET as
   cursor c_cur_invrel is select inv_comp_code, inv_job_code, inv_num, inv_cust_code, inv_cont_code, 
                       (-1) * inv_hldbk_amt inv_hldbk_amt, inv_post_date, inv_bch_num 
                       from da.invoice
                       where 
                       inv_status_code not in ('V')
                       and inv_post_date   is not null
                       and inv_rev_date    is null
                       and nvl(inv_hldbk_amt,0) < 0
                       order by inv_post_date, inv_num;


    cursor invrlsdet_v_zero_lines_cur ( p_comp_code         varchar2,
                                        p_job_code          varchar2,
                                        p_cust_code         varchar2,
                                        p_inv_num           varchar2,
                                        p_cont_code         varchar2) 
    is
      select inv_num,
             inv_hldbk_amt,
             inv_rls_amt,
             inv_job_code,
             inv_post_date,
             nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) inv_ret_outstand_amt
      from   da.invoice
      where  inv_job_code     is null
      and    p_job_code       is null 
      and    p_cont_code is null
      and    inv_cont_code    is null
      and    (nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) >  0)
      and inv_num         != p_inv_num
      and    inv_cust_code    = p_cust_code
      and    inv_comp_code    = p_comp_code
      and    inv_post_date    is not null
      and    inv_rev_date     is null
      and    inv_status_code != 'V'
      union all
      select inv_num,
             inv_hldbk_amt,
             inv_rls_amt,
             inv_job_code,
             inv_post_date,
             nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) inv_ret_outstand_amt
      from   da.invoice
      where  (inv_job_code = p_job_code
                     or inv_job_code in
                          (select job_code from da.jcjob_table
                            where job_comp_code = p_comp_code
                              and job_ctrl_code = p_job_code))
             and p_cont_code is null
             and inv_cont_code is null
             and    (nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) >  0)
             and inv_num         != p_inv_num
             and    inv_cust_code    = p_cust_code
             and    inv_comp_code    = p_comp_code
             and    inv_post_date    is not null
             and    inv_rev_date     is null
             and    inv_status_code != 'V'
      union all
      select inv_num,
             inv_hldbk_amt,
             inv_rls_amt,
             inv_job_code,
             inv_post_date,
             nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) inv_ret_outstand_amt
      from   da.invoice
      where  (inv_job_code = p_job_code
                     or inv_job_code in
                          (select job_code from da.jcjob_table
                            where job_comp_code = p_comp_code
                              and job_ctrl_code = p_job_code))
             and p_cont_code is not null
             and inv_cont_code = p_cont_code
             and    (nvl(inv_hldbk_amt,0) - nvl(inv_rls_amt,0) >  0)
             and inv_num         != p_inv_num
             and    inv_cust_code    = p_cust_code
             and    inv_comp_code    = p_comp_code
             and    inv_post_date    is not null
             and    inv_rev_date     is null
             and    inv_status_code != 'V'
      order by 5,1;


t_rls_amt number:=0; 
t_inv_rls_amt number:=0; 

begin

-- select all the vouchers with negative release
for c_rec_invrel in c_cur_invrel loop

-- this is the release amount
t_rls_amt := c_rec_invrel.inv_hldbk_amt;

-- search for outstanding vouchers
for k in invrlsdet_v_zero_lines_cur(c_rec_invrel.inv_comp_code, c_rec_invrel.inv_job_code, 
                                    c_rec_invrel.inv_cust_code, c_rec_invrel.inv_num, c_rec_invrel.inv_cont_code) loop

t_inv_rls_amt := least(t_rls_amt, k.inv_ret_outstand_amt);

update da.invoice
set inv_rls_amt = nvl(inv_rls_amt,0) - NVL(t_inv_rls_amt,0)
where inv_num = c_rec_invrel.inv_num; -- this is the invoice which had negative retainage = release

update da.invoice
set inv_rls_amt = nvl(inv_rls_amt,0) + nvl(t_inv_rls_amt,0)
where inv_num = k.inv_num; -- this is the invoice with outstanding retainage  

if nvl(t_inv_rls_amt,0) <> 0 then
insert into da.invrlsdet
(ird_comp_code 
,ird_bch_num 
,ird_inv_num 
,ird_orig_inv_num 
,ird_rls_amt 
,ird_rls_tax1_amt  --??
,ird_post_date 
,ird_cust_code )
values
(c_rec_invrel.inv_comp_code
,c_rec_invrel.inv_bch_num
,c_rec_invrel.inv_num
,k.inv_num
,nvl(t_inv_rls_amt,0)
,0                    
,c_rec_invrel.inv_post_date
,c_rec_invrel.inv_cust_code);
end if;

t_rls_amt := t_rls_amt - t_inv_rls_amt;
exit when invrlsdet_v_zero_lines_cur%notfound or t_rls_amt = 0;
end loop;

exit when c_cur_invrel%notfound;
end loop;
commit;
end;
/
show errors;
