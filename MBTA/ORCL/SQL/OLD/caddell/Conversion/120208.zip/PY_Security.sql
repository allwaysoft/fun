begin
for i in
(select
  decode(emp_type, 'H','HOURLY','SALARY') v
 , emp_no
 from pyemployee_table
 where emp_no not in
 (select esge_emp_no from DA.PYEMPSECGRPEMP)
) loop
insert into DA.PYEMPSECGRPEMP
(esge_group_code, esge_emp_no)
values
(i.v, i.emp_no)
;
end loop;
commit;
end;
