begin
for i in
(select 'MASTER' v, job_code, job_comp_code
from jcjob_table
where job_comp_code = '01'
and job_code not in
(select jcgj_job_code from da.jcjobsecgrpjob)
) loop
insert into da.jcjobsecgrpjob
(jcgj_group_code, jcgj_job_code, jsgj_comp_code)
values
(i.v, i.job_code, i.job_comp_code)
;
end loop;
commit;
end;
/

