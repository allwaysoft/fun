rem    syntax for running script: start dcscproj.sql
prompt SQL Script to link subcontracts to projects
prompt Run after importing all subcontracts and entering all projects.

update da.scmast 
   set scmst_proj_oraseq = 
      (select pmp_proj_oraseq from da.pmproject_table
        where pmp_comp_code = scmst_comp_code 
          and pmp_job_code = scmst_job_code and rownum < 2)
 where scmst_proj_oraseq is null
   and (scmst_comp_code, scmst_job_code) in 
        (select pmp_comp_code, pmp_job_code 
           from da.pmproject_table);

commit;
